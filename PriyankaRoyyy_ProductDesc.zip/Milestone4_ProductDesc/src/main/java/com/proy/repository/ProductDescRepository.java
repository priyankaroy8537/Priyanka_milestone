package com.proy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.proy.entity.ProductDescEntity;



@Repository
public interface ProductDescRepository extends JpaRepository<ProductDescEntity, Integer> {

}
