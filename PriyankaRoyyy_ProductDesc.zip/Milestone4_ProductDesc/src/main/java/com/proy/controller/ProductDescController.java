package com.proy.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proy.entity.ProductDescEntity;
import com.proy.repository.ProductDescRepository;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("productdesc")
@CrossOrigin
public class ProductDescController {

	@Autowired
	private ProductDescRepository ProductDescRepository;
	
	@GetMapping("/byid/{id}")
	public Optional<ProductDescEntity> getMethodName(@PathVariable Integer id) {
		return ProductDescRepository.findById(id);
	
	}
	
	@GetMapping
	public List<ProductDescEntity> getAll() {
		return ProductDescRepository.findAll();
	}
	
	
	@PostMapping("/add")
	public ProductDescEntity postMethodName(@RequestBody ProductDescEntity entity) {
		
		return ProductDescRepository.save(entity);
	}
	
	
}
