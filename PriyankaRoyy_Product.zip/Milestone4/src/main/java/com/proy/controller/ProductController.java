package com.proy.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proy.VO.ProductDescVO;
import com.proy.entity.ProductEntity;
import com.proy.repository.ProductRepository;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("product")
public class ProductController {
	
	@Autowired
	private ProductRepository repository;
	
	@Autowired
	private Consumer consumer;
	
	
	@GetMapping("/byid/{id}")
	public Optional<ProductEntity> getMethodName(@PathVariable Integer id) {
		return repository.findById(id);
	}
	
	@GetMapping("/productanddesc/{id}")
	public Optional<ProductDescVO> getMarks(@PathVariable Integer id) {
		return consumer.getProductDesc(id);
	}
	
	
	
	@GetMapping("/bylname/{lname}")
	public List<ProductEntity> getMethodName(@PathVariable String type) {
		return repository.findByType(type);
	}
	
	
	@PostMapping("/add")
	public ProductEntity postMethodName(@RequestBody ProductEntity entity) {
		
		return repository.save(entity);
	}
	
	
	
	
	
	

}
